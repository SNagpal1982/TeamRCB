package teamrcbpackage;

public interface AutoConst 
{
	//Cricket Team - Royal Challengers, Bangalore
	String TEAM_RCB = ".//InputFile//TeamRCB.json";


}
