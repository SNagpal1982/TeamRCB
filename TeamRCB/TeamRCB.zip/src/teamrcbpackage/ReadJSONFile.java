package teamrcbpackage;

import static org.testng.Assert.assertFalse;

import java.io.FileNotFoundException;
import java.io.FileReader;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/*import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.google.gson.stream.*;*/

public class ReadJSONFile 
{

	public static void main(String[] args) {
		
		readJSONElement(AutoConst.TEAM_RCB);
		 
	}
	public static void readJSONElement(String jsonFilePath) 
	{

		try 
		{
			
			int foreignPlayerCount = 0;
			FileReader fileReader = new FileReader(jsonFilePath);
			JsonObject jsonObject = JsonParser.parseReader(fileReader).getAsJsonObject();
			System.out.println("Team Name : " + jsonObject.get("name"));
			System.out.println("Team Location : " + jsonObject.get("location"));
			System.out.println("======================");
			System.out.println("Player Details");
			System.out.println("======================");
			JsonArray playerDetails = (JsonArray) jsonObject.get("player");
			System.out.println("Total Player : " + playerDetails.size());
			// Read Json file
			for (int i =0; i<playerDetails.size(); i++)
			{
				System.out.println(playerDetails.get(i));
				
				if ((isPlayerForeigner ((JsonObject) playerDetails.get(i), "India")) )
				{
					foreignPlayerCount = foreignPlayerCount+1;  
				}
			}
			System.out.println("foreignPlayerCount : " + foreignPlayerCount);
		}
		catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static boolean isPlayerForeigner (JsonObject jsonPlayerElement, String ownCountryName) throws FileNotFoundException 
	{
		String playerCountryName = jsonPlayerElement.get("country").toString();
		
		System.out.println("playerCountryName : " + playerCountryName +"; " + 
							"ownCountryName : " + ownCountryName);
		
		
		 if ( playerCountryName.equalsIgnoreCase(ownCountryName)) 
		 {
			 System.out.println("I win");
		  }
		 else
		 {
			 System.out.println("Need Improvment");
		  }
			 
		 
		///System.out.println(ownCountryName);
		
		/*
		 * if ( (jsonPlayerElement.get("country").toString()).compareTo(ownCountryName)
		 * == 0 ) {
		 * System.out.println("country name : "+jsonPlayerElement.get("country").
		 * toString()); return false; } else { //System.out.println("Name : " +
		 * jsonPlayerElement.get("name")); //System.out.println("country : " +
		 * jsonPlayerElement.get("country")); //System.out.println("role : " +
		 * jsonPlayerElement.get("role")); //System.out.println("price : " +
		 * jsonPlayerElement.get("price-in-crores")); return true; }
		 */	
	return true;	
	}
	
	public static void writeJSONElement(String jsonFilePath) throws FileNotFoundException {

		  FileReader reader = new FileReader(jsonFilePath);
		  System.out.println(reader);
		  
	
	}

	
	

}