package teamrcbpackage;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

public class TeamRCB 
{
  @Test
  public void f() 
  {
	  var a =10;
	  assertEquals(a, 10);
  }
}
